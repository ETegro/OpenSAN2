-----------------------------------------------------------------
-- @release $Id: raw.lua,v 1.5 2007/04/18 14:28:39 tomas Exp $
-----------------------------------------------------------------

module "luadoc.doclet.raw"

-----------------------------------------------------------------
-- Generate the output.
-- @param doc Table with the structured documentation.

function start (doc)
end
